package dio.springboot.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIocDiBeansAutowiredApplicationTests {

	@Test
	void contextLoads() {
	}

}
